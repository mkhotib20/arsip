<li class="nav-item <?php if($this->uri->segment(2)=='pengarsipan'){echo 'active';} ?>">
        <a class="nav-link" href="<?php echo base_url('dokumen/pengarsipan') ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Pengarsipan Dokumen</span></a>
      </li>
      
